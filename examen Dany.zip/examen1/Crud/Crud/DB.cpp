#include "pch.h"
#include "DB.h"


DB::DB()
{
	this->connectionString = "datasource=localhost; username=root; password=""; database=vehiculo;";
	this->conn = gcnew MySqlConnection(this->connectionString);

}

void DB::AbrirConexion()
{
	this->conn->Open();
}

void DB::CerrarConexion()
{
	this->conn->Close();
}

DataTable^ DB::getData()
{
	String^ sql = "select * from prueba";
	MySqlCommand^ cursor = gcnew MySqlCommand(sql, this->conn);
	MySqlDataAdapter^ data = gcnew MySqlDataAdapter(cursor);
	DataTable^ tabla = gcnew DataTable();
	data->Fill(tabla);
	return tabla;
}
void DB::insertar(String^ name, String^ a, String^ ma, String^ s)
{
	String^ sql = "insert into prueba(nombre, a�o, marca, serie) values (�" + name + "�, " + a + ", �" + ma + "�, �" + s + "�)";
	MySqlCommand^ cursor = gcnew MySqlCommand(sql, this->conn);
	try
	{
		cursor->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}

