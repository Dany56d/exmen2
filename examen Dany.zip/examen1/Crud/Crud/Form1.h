#pragma once
#include "DB.h"

namespace CppCLRWinFormsProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			this->data = gcnew DB();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^ txt_nombre;
	protected:
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ txt_anio;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ txt_serie;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::TextBox^ txt_marca;

	private: System::Windows::Forms::Button^ btn_guardar;
	private: System::Windows::Forms::DataGridView^ datagrid;
	private: DB^ data;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txt_nombre = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txt_anio = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txt_serie = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txt_marca = (gcnew System::Windows::Forms::TextBox());
			this->btn_guardar = (gcnew System::Windows::Forms::Button());
			this->datagrid = (gcnew System::Windows::Forms::DataGridView());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->datagrid))->BeginInit();
			this->SuspendLayout();
			// 
			// txt_nombre
			// 
			this->txt_nombre->Location = System::Drawing::Point(29, 178);
			this->txt_nombre->Name = L"txt_nombre";
			this->txt_nombre->Size = System::Drawing::Size(625, 38);
			this->txt_nombre->TabIndex = 0;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(306, 143);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(92, 32);
			this->label1->TabIndex = 1;
			this->label1->Text = L"label1";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(306, 252);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(92, 32);
			this->label2->TabIndex = 3;
			this->label2->Text = L"label2";
			// 
			// txt_anio
			// 
			this->txt_anio->Location = System::Drawing::Point(29, 303);
			this->txt_anio->Name = L"txt_anio";
			this->txt_anio->Size = System::Drawing::Size(625, 38);
			this->txt_anio->TabIndex = 2;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(306, 388);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(92, 32);
			this->label3->TabIndex = 5;
			this->label3->Text = L"label3";
			// 
			// txt_serie
			// 
			this->txt_serie->Location = System::Drawing::Point(29, 423);
			this->txt_serie->Name = L"txt_serie";
			this->txt_serie->Size = System::Drawing::Size(625, 38);
			this->txt_serie->TabIndex = 4;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(306, 523);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(92, 32);
			this->label4->TabIndex = 7;
			this->label4->Text = L"label4";
			// 
			// txt_marca
			// 
			this->txt_marca->Location = System::Drawing::Point(29, 558);
			this->txt_marca->Name = L"txt_marca";
			this->txt_marca->Size = System::Drawing::Size(625, 38);
			this->txt_marca->TabIndex = 6;
			// 
			// btn_guardar
			// 
			this->btn_guardar->Location = System::Drawing::Point(112, 644);
			this->btn_guardar->Name = L"btn_guardar";
			this->btn_guardar->Size = System::Drawing::Size(372, 85);
			this->btn_guardar->TabIndex = 8;
			this->btn_guardar->Text = L"button1";
			this->btn_guardar->UseVisualStyleBackColor = true;
			this->btn_guardar->Click += gcnew System::EventHandler(this, &Form1::btn_guardar_Click);
			// 
			// datagrid
			// 
			this->datagrid->AllowUserToOrderColumns = true;
			this->datagrid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->datagrid->Location = System::Drawing::Point(696, 147);
			this->datagrid->Name = L"datagrid";
			this->datagrid->RowHeadersWidth = 102;
			this->datagrid->RowTemplate->Height = 40;
			this->datagrid->Size = System::Drawing::Size(1606, 603);
			this->datagrid->TabIndex = 9;
			this->datagrid->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::datagrid_CellContentClick);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(16, 31);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(2314, 1076);
			this->Controls->Add(this->datagrid);
			this->Controls->Add(this->btn_guardar);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txt_marca);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txt_serie);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txt_anio);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txt_nombre);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->datagrid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^ sender, System::EventArgs^ e) {
		this->Consulta();
	}
private: System::Void datagrid_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
	
}
	   public: void Consulta()
	   {
		   this->data->AbrirConexion();
		   this->datagrid->DataSource = this->data->getData();
		   this->data->CerrarConexion();
	   }

private: System::Void btn_guardar_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Consulta();
	this->data->AbrirConexion();
	this->data->insertar(this->txt_nombre->Text, this->txt_anio->Text, this->txt_serie->Text, this->txt_marca->Text);
	this->data->CerrarConexion();
	
}
};
}
