#pragma once
#include "Form1.h"
#include "DB.h"
#include "modificar.h"

namespace CppCLR_WinFormsProject1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	


	/// <summary>
	/// Resumen de login
	/// </summary>
	public ref class login : public System::Windows::Forms::Form
	{
	public:
		login(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
			this->data = gcnew Estudiantes();
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~login()
		{
			if (components)
			{
				delete components;
			}
		}
	private: String^ connectionString = "datasource=localhost; username= root; password=""; database=vehiculo;";
	private: MySqlConnection^ conn = gcnew MySqlConnection(connectionString);
	private: System::Windows::Forms::TextBox^ txt_usuario;
	protected:

	protected:
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ txt_contrasenia;
	private: System::Windows::Forms::Button^ btn_entrar;


	private: Estudiantes^ data;



	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txt_usuario = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txt_contrasenia = (gcnew System::Windows::Forms::TextBox());
			this->btn_entrar = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// txt_usuario
			// 
			this->txt_usuario->BackColor = System::Drawing::Color::RosyBrown;
			this->txt_usuario->Font = (gcnew System::Drawing::Font(L"Century Gothic", 11.1F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->txt_usuario->Location = System::Drawing::Point(360, 213);
			this->txt_usuario->Name = L"txt_usuario";
			this->txt_usuario->Size = System::Drawing::Size(432, 53);
			this->txt_usuario->TabIndex = 0;
			this->txt_usuario->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 11.1F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(501, 164);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(151, 46);
			this->label1->TabIndex = 1;
			this->label1->Text = L"Usuario";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 11.1F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(460, 346);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(228, 46);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Contrase�a";
			// 
			// txt_contrasenia
			// 
			this->txt_contrasenia->BackColor = System::Drawing::Color::Salmon;
			this->txt_contrasenia->Font = (gcnew System::Drawing::Font(L"Century Gothic", 11.1F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->txt_contrasenia->Location = System::Drawing::Point(360, 395);
			this->txt_contrasenia->Name = L"txt_contrasenia";
			this->txt_contrasenia->PasswordChar = '*';
			this->txt_contrasenia->Size = System::Drawing::Size(432, 53);
			this->txt_contrasenia->TabIndex = 2;
			this->txt_contrasenia->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			// 
			// btn_entrar
			// 
			this->btn_entrar->BackColor = System::Drawing::Color::IndianRed;
			this->btn_entrar->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->btn_entrar->FlatAppearance->BorderSize = 0;
			this->btn_entrar->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->btn_entrar->Font = (gcnew System::Drawing::Font(L"Century Gothic", 11.1F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btn_entrar->Location = System::Drawing::Point(360, 569);
			this->btn_entrar->Name = L"btn_entrar";
			this->btn_entrar->Size = System::Drawing::Size(432, 72);
			this->btn_entrar->TabIndex = 4;
			this->btn_entrar->Text = L"Entrar";
			this->btn_entrar->UseVisualStyleBackColor = false;
			this->btn_entrar->Click += gcnew System::EventHandler(this, &login::btn_login_Click);
			// 
			// login
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(16, 31);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightGray;
			this->ClientSize = System::Drawing::Size(1179, 887);
			this->Controls->Add(this->btn_entrar);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txt_contrasenia);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txt_usuario);
			this->Name = L"login";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"login";
			this->TransparencyKey = System::Drawing::Color::Transparent;
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void btn_login_Click(System::Object^ sender, System::EventArgs^ e) {

		String^ sql = "select * from login where Usuario = '" + txt_usuario->Text + "' and Contrase�a = '" + txt_contrasenia->Text + "'";
		MySqlCommand^ cursor = gcnew MySqlCommand(sql, conn);
		MySqlDataReader^ datareader;

		try
		{
			this->conn->Open();
			datareader = cursor->ExecuteReader();
			if (datareader->Read())
			{
				Form1^ formulario_disenio = gcnew Form1();
				formulario_disenio->ShowDialog();
				this->Close();

			}
			else {
				MessageBox::Show(L"Usuario incorrecto ");

			}
		}
		catch (Exception^ x) {
			MessageBox::Show(x->Message);

		}
	}
	};
}
