#pragma once
using namespace std;
using namespace System;
using namespace System::Data;
using namespace MySql::Data::MySqlClient;


ref class Estudiantes
{
private:
	String^ connectionString;
	MySqlConnection^ conn;
public:
	Estudiantes();
	DataTable^ getData();
	void AbrirConexion();
	void CerrarConexion();
	void create(String^, String^, String^, String^);
	void update(String^, String^, String^, String^, String^);
	void remove(String^);
};

