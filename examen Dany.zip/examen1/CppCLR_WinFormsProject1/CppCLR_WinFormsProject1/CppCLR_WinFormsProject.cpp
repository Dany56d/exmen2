#include "pch.h"


using namespace System;

// int main(array<System::String ^> ^args)
// {
//    return 0;
// }

#include "login.h"

using namespace System::Windows::Forms;

[STAThread]
int main()
{
  Application::EnableVisualStyles();
  Application::SetCompatibleTextRenderingDefault(false);
  Application::Run(gcnew CppCLR_WinFormsProject1::login());
 
  return 0;
}