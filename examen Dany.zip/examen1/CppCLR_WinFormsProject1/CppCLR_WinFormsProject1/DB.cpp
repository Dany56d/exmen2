#include "pch.h"
#include "DB.h"


Estudiantes::Estudiantes()
{
	this->connectionString = "datasource=localhost; username=root; password=""; database=vehiculo;";
	this->conn = gcnew MySqlConnection(this->connectionString);

}

void Estudiantes::AbrirConexion()
{
	this->conn->Open();
}

void Estudiantes::CerrarConexion()
{
	this->conn->Close();
}

DataTable^ Estudiantes::getData()
{
	String^ sql = "select * from vehiculo";
	MySqlCommand^ cursor = gcnew MySqlCommand(sql, this->conn);
	MySqlDataAdapter^ data = gcnew MySqlDataAdapter(cursor);
	DataTable^ tabla = gcnew DataTable();
	data->Fill(tabla);
	return tabla;
}
void Estudiantes::create(String^ name, String^ a, String^ ma, String^ s)
{
	String^ sql = "insert into vehiculo(Nombre, A�o_de_fabricacion, Marca, Motor) values ('"+name+"', "+a+", '"+ma+"', '"+s+"')";
	MySqlCommand^ cursor = gcnew MySqlCommand(sql, this->conn);
	try
	{
		cursor->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}
}
void Estudiantes::update(String^ name, String^ a, String^ ma, String^ s, String^ ref)
{
	String^ sql = "update vehiculo set Nombre = '" + name + "', A�o_de_fabricacion = '" + a + "', Marca = '" + ma + "', Motor = '" + s + "' where id = '" + ref + "'";
	MySqlCommand^ cursor = gcnew MySqlCommand(sql, this->conn);
	try
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		cursor->ExecuteNonQuery();
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}

}
void Estudiantes::remove(String^ id)
{
	String^ sql = "delete from vehiculo where id = '" + id + "'";
	MySqlCommand^ cursor = gcnew MySqlCommand(sql, this->conn);
	try
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		cursor->ExecuteNonQuery();
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(L"Eliminado correctamente!");
	}
	catch (Exception^ e)
	{
		using namespace System::Windows::Forms;
		using namespace System::Data;
		using namespace System::Drawing;
		MessageBox::Show(e->Message);
	}

}